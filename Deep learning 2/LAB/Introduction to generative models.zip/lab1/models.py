import math
from typing import Union, Collection

import tensorflow as tf

TFData = Union[tf.Tensor, tf.Variable, float]

class GMModel:
    def __init__(self, K):
        self.K = K
        self.mean = tf.Variable(tf.random.normal(shape=[K]))
        self.logvar = tf.Variable(tf.random.normal(shape=[K]))
        self.logpi = tf.Variable(tf.zeros(shape=[K]))

    @property
    def variables(self) -> Collection[TFData]:
        return self.mean, self.logvar, self.logpi

    @staticmethod
    def neglog_normal_pdf(x: TFData, mean: TFData, logvar: TFData):
        var = tf.exp(logvar)

        return 0.5 * (tf.math.log(2 * math.pi) + logvar + (x - mean) ** 2 / var)

    @tf.function
    def loss(self, data: TFData):
        neglog_pdf = self.neglog_normal_pdf(x=data, mean=self.mean, logvar=self.logvar)
        log_sum_exp = tf.reduce_logsumexp(self.logpi, axis=0)
        
        neglog_pi = log_sum_exp - self.logpi
        return -tf.reduce_logsumexp(-(neglog_pdf + neglog_pi), axis=1)

        return -tf.reduce_logsumexp(-(neglog_pdf) + neglog_pi, axis=0)
    def p_xz(self, x: TFData, k: int) -> TFData:
        return tf.exp(-self.neglog_normal_pdf(x, self.mean[k], self.logvar[k]))

    def p_x(self, x: TFData) -> TFData:
        return tf.math.reduce_sum([tf.nn.softmax(self.logpi)[k] * self.p_xz(x, k) for k in range(self.K)], axis=0)
